// API Configuration
const API_BASE_URL = 'http://localhost:3000/api';

// Anonymous Token Management
let anonymousToken = null;
let currentFeedTab = 'active'; // 'active' or 'archived'

// Initialize token on page load
function initializeToken() {
    // Check if token exists in localStorage
    anonymousToken = localStorage.getItem('anonymousToken');

    if (!anonymousToken) {
        // Generate new random token (32 bytes = 64 hex characters)
        const array = new Uint8Array(32);
        crypto.getRandomValues(array);
        anonymousToken = Array.from(array, byte => byte.toString(16).padStart(2, '0')).join('');

        // Store in localStorage
        localStorage.setItem('anonymousToken', anonymousToken);
        console.log('✓ New anonymous token generated');
    } else {
        console.log('✓ Existing token loaded from localStorage');
    }
}

// Hash token using SHA-256 before sending to server
async function hashToken(token) {
    const encoder = new TextEncoder();
    const data = encoder.encode(token);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(byte => byte.toString(16).padStart(2, '0')).join('');
}

// Load and display user status
async function loadUserStatus() {
    try {
        const hashedToken = await hashToken(anonymousToken);

        // Display short token hash
        document.getElementById('user-token').textContent = hashedToken.substring(0, 8) + '…';

        // Fetch credibility data
        const response = await fetch(`${API_BASE_URL}/credibility/${hashedToken}`);
        const data = await response.json();

        if (data.success) {
            document.getElementById('user-credibility').textContent = data.credibility.toFixed(2);

            // Get member since from localStorage or set it
            let memberSince = localStorage.getItem('memberSince');
            if (!memberSince) {
                memberSince = new Date().toISOString();
                localStorage.setItem('memberSince', memberSince);
            }

            const date = new Date(memberSince);
            const formatted = date.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
            document.getElementById('member-since').textContent = formatted;
        }
    } catch (error) {
        console.error('Error loading user status:', error);
        document.getElementById('user-credibility').textContent = '0.10';
        document.getElementById('member-since').textContent = 'Today';
    }
}

// Format timestamp to relative time
function formatTimestamp(timestamp) {
    const now = Date.now();
    const diff = now - timestamp;

    const seconds = Math.floor(diff / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (days > 0) return `${days}d ago`;
    if (hours > 0) return `${hours}h ago`;
    if (minutes > 0) return `${minutes}m ago`;
    return 'Just now';
}

// Get trust label based on score
function getTrustLabel(score, totalVotes) {
    if (totalVotes === 0) {
        return { text: 'No Votes Yet', class: 'unverified' };
    }

    if (score > 0.3) {
        return { text: 'Leaning True', class: 'leaning-true' };
    } else if (score < -0.3) {
        return { text: 'Leaning False', class: 'leaning-false' };
    } else if (score >= -0.1 && score <= 0.1 && totalVotes >= 3) {
        return { text: 'Contested', class: 'contested' };
    } else {
        return { text: 'Unverified', class: 'unverified' };
    }
}

// Check if user has voted on a rumor
function hasVoted(rumorId) {
    const votes = JSON.parse(localStorage.getItem('userVotes') || '{}');
    return votes[rumorId] || false;
}

// Record that user voted on a rumor
function recordVote(rumorId, voteType) {
    const votes = JSON.parse(localStorage.getItem('userVotes') || '{}');
    votes[rumorId] = voteType;
    localStorage.setItem('userVotes', JSON.stringify(votes));
}

// Fetch and display all rumors
async function loadRumors() {
    const rumorsFeed = document.getElementById('rumor-feed');
    const hashedToken = await hashToken(anonymousToken);

    try {
        const response = await fetch(`${API_BASE_URL}/rumors`);
        const data = await response.json();

        if (data.success && data.rumors.length > 0) {
            // Filter based on selected tab
            const filteredRumors = data.rumors.filter(r =>
                currentFeedTab === 'active' ? r.status === 'ACTIVE' : r.status === 'ARCHIVED'
            );

            if (filteredRumors.length === 0) {
                rumorsFeed.innerHTML = `<div class="empty-state">No ${currentFeedTab} rumors found.</div>`;
                return;
            }

            rumorsFeed.innerHTML = filteredRumors.map(rumor => {
                const totalVotes = rumor.verify_count + rumor.dispute_count;
                const trustLabel = getTrustLabel(rumor.trust_score, totalVotes);
                const voted = hasVoted(rumor.id);
                const isOwner = rumor.submitter_token === hashedToken;
                const isArchived = rumor.status === 'ARCHIVED';

                return `
          <div class="rumor-card ${isArchived ? 'archived' : ''}" data-rumor-id="${rumor.id}">
            ${isArchived ? '<div class="archive-banner">📜 Archived / Read Only</div>' : ''}
            <div class="rumor-header">
              <div class="trust-info">
                <span class="trust-label ${trustLabel.class}">${trustLabel.text}</span>
                <span class="trust-score-display">Score: ${rumor.trust_score.toFixed(3)}</span>
              </div>
              <span class="rumor-timestamp">${formatTimestamp(rumor.timestamp)}</span>
            </div>
            <p class="rumor-content">${escapeHtml(rumor.content)}</p>
            <div class="rumor-footer">
              <div class="vote-section">
                ${!isArchived ? `
                <button class="vote-btn verify ${voted === 'verify' ? 'active' : ''}" 
                        data-rumor-id="${rumor.id}" 
                        data-vote-type="verify"
                        ${voted || isOwner ? 'disabled' : ''}
                        title="${isOwner ? 'You cannot vote on your own rumor' : ''}">
                  <span>✓ Verify</span>
                  <span class="vote-count">${rumor.verify_count}</span>
                </button>
                <button class="vote-btn dispute ${voted === 'dispute' ? 'active' : ''}" 
                        data-rumor-id="${rumor.id}" 
                        data-vote-type="dispute"
                        ${voted || isOwner ? 'disabled' : ''}
                        title="${isOwner ? 'You cannot vote on your own rumor' : ''}">
                  <span>✗ Dispute</span>
                  <span class="vote-count">${rumor.dispute_count}</span>
                </button>
                ` : `
                <div class="final-counts">
                  Verified: ${rumor.verify_count} | Disputed: ${rumor.dispute_count}
                </div>
                `}
              </div>
              ${isOwner && !isArchived ? `
                <div class="owner-actions">
                  <button class="delete-btn" data-rumor-id="${rumor.id}">Delete & Penalty</button>
                </div>
              ` : ''}
            </div>
          </div>
        `;
            }).join('');

            // Add vote button listeners
            document.querySelectorAll('.vote-btn:not([disabled])').forEach(btn => {
                btn.addEventListener('click', handleVote);
            });

            // Add delete button listeners
            document.querySelectorAll('.delete-btn').forEach(btn => {
                btn.addEventListener('click', handleDelete);
            });
        } else {
            rumorsFeed.innerHTML = '<div class="empty-state">No rumors yet. Be the first to share!</div>';
        }
    } catch (error) {
        console.error('Error loading rumors:', error);
        rumorsFeed.innerHTML = '<div class="empty-state">Failed to load rumors. Please try again.</div>';
    }
}

// Escape HTML to prevent XSS
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Handle rumor submission
async function handleSubmit(e) {
    e.preventDefault();

    const contentInput = document.getElementById('rumor-content');
    const content = contentInput.value.trim();
    const submitBtn = document.getElementById('submit-btn');

    if (!content) return;

    // Disable button during submission
    submitBtn.disabled = true;
    submitBtn.querySelector('.btn-text').textContent = 'Submitting...';

    const confidenceWeight = parseFloat(document.getElementById('submit-confidence').value);

    try {
        const hashedToken = await hashToken(anonymousToken);

        const response = await fetch(`${API_BASE_URL}/rumors`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                content,
                hashedToken,
                confidenceWeight
            })
        });

        const data = await response.json();

        if (data.success) {
            // Clear form
            contentInput.value = '';
            document.getElementById('char-count').textContent = '0 / 500';

            // Reload rumors
            await loadRumors();
            console.log('✓ Rumor submitted successfully');
        } else {
            alert('Failed to submit rumor: ' + data.error);
        }
    } catch (error) {
        console.error('Error submitting rumor:', error);
        alert('Failed to submit rumor. Please try again.');
    } finally {
        submitBtn.disabled = false;
        submitBtn.querySelector('.btn-text').textContent = 'Share Anonymously';
    }
}

// Handle deletion
async function handleDelete(e) {
    const btn = e.currentTarget;
    const rumorId = parseInt(btn.dataset.rumorId);

    if (!confirm('WARNING: Deleting your rumor will permanently remove it and REDUCE your credibility by 0.1. Proceed?')) {
        return;
    }

    try {
        const hashedToken = await hashToken(anonymousToken);
        const response = await fetch(`${API_BASE_URL}/delete`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ rumorId, hashedToken })
        });

        const data = await response.json();
        if (data.success) {
            console.log('✓ Rumor deleted, penalty applied');
            await loadRumors();
            await loadUserStatus(); // Refresh credibility
        } else {
            alert('Delete failed: ' + data.error);
        }
    } catch (error) {
        console.error('Error deleting:', error);
    }
}

// Handle voting - shows confirmation modal first
async function handleVote(e) {
    const btn = e.currentTarget;
    const rumorId = parseInt(btn.dataset.rumorId);
    const voteType = btn.dataset.voteType;

    // Show confirmation modal
    showVoteModal(rumorId, voteType, btn);
}

// Show vote confirmation modal
function showVoteModal(rumorId, voteType, originalBtn) {
    const modal = document.getElementById('vote-modal');
    const yesBtn = document.getElementById('vote-yes');
    const noBtn = document.getElementById('vote-no');
    const confidenceDropdown = document.getElementById('confidence-level');

    // Reset dropdown and disable yes button
    confidenceDropdown.value = '';
    yesBtn.disabled = true;

    // Enable yes button when confidence is selected
    const handleConfidenceChange = () => {
        yesBtn.disabled = !confidenceDropdown.value;
    };
    confidenceDropdown.addEventListener('change', handleConfidenceChange);

    // Show modal
    modal.style.display = 'flex';

    // Handle Yes - proceed with vote
    const handleYes = async () => {
        const confidenceWeight = parseFloat(confidenceDropdown.value);
        cleanup();
        await submitVote(rumorId, voteType, confidenceWeight, originalBtn);
    };

    // Handle No - cancel
    const handleNo = () => {
        cleanup();
    };

    // Cleanup function
    const cleanup = () => {
        modal.style.display = 'none';
        yesBtn.removeEventListener('click', handleYes);
        noBtn.removeEventListener('click', handleNo);
        confidenceDropdown.removeEventListener('change', handleConfidenceChange);
    };

    // Add event listeners
    yesBtn.addEventListener('click', handleYes);
    noBtn.addEventListener('click', handleNo);

    // Close on overlay click
    const overlay = modal.querySelector('.modal-overlay');
    overlay.addEventListener('click', handleNo, { once: true });
}

// Submit the actual vote
async function submitVote(rumorId, voteType, confidenceWeight, btn) {
    // Disable button during voting
    btn.disabled = true;

    try {
        const hashedToken = await hashToken(anonymousToken);

        const response = await fetch(`${API_BASE_URL}/vote`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                rumorId,
                hashedToken,
                voteType,
                confidenceWeight
            })
        });

        const data = await response.json();

        if (data.success) {
            // Record vote locally
            recordVote(rumorId, voteType);

            // Reload rumors and status
            await loadRumors();
            await loadUserStatus();

            console.log('✓ Vote recorded');
        } else {
            alert(data.error || 'Failed to record vote');
            btn.disabled = false;
        }
    } catch (error) {
        console.error('Error voting:', error);
        alert('Failed to record vote. Please try again.');
        btn.disabled = false;
    }
}

// Character counter
function updateCharCount() {
    const textarea = document.getElementById('rumor-content');
    const charCount = document.getElementById('char-count');
    charCount.textContent = `${textarea.value.length} / 500`;
}

// Initialize app
document.addEventListener('DOMContentLoaded', async () => {
    console.log('🚀 App initializing...');
    try {
        // Initialize anonymous token
        initializeToken();
        console.log('✓ Token initialized');

        // Load user status
        await loadUserStatus();
        console.log('✓ User status loaded');

        // Load rumors
        await loadRumors();
        console.log('✓ Rumors loaded');

        // Set up form submission
        const form = document.getElementById('rumor-form');
        if (form) {
            form.addEventListener('submit', handleSubmit);
            console.log('✓ Form listener attached');
        } else {
            console.error('✗ rumor-form not found');
        }

        // Set up character counter
        const textarea = document.getElementById('rumor-content');
        if (textarea) {
            textarea.addEventListener('input', updateCharCount);
            console.log('✓ Char counter listener attached');
        } else {
            console.error('✗ rumor-content not found');
        }

        // Set up refresh button
        const refreshBtn = document.getElementById('refresh-btn');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', loadRumors);
            console.log('✓ Refresh listener attached');
        } else {
            console.error('✗ refresh-btn not found');
        }

        // Set up tab switching
        document.querySelectorAll('.feed-tab').forEach(tab => {
            tab.addEventListener('click', (e) => {
                document.querySelectorAll('.feed-tab').forEach(t => t.classList.remove('active'));
                e.target.classList.add('active');
                currentFeedTab = e.target.dataset.tab;
                loadRumors();
            });
        });

        console.log('✅ App ready');
    } catch (error) {
        console.error('❌ App initialization failed:', error);
    }
});
